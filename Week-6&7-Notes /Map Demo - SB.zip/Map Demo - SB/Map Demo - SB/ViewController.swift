//
//  ViewController.swift
//  Map Demo - SB
//
//  Created by Xiaoping Jia on 3/26/21.
//

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var message: UILabel!
    
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
            let status = locationManager.authorizationStatus
            if status == .denied || status == .restricted {
                message.text = "Location service not authorized"
            } else {
                locationManager.desiredAccuracy = kCLLocationAccuracyBest
                locationManager.distanceFilter = 1 // meter
                locationManager.delegate = self
                locationManager.requestWhenInUseAuthorization()
                
                mapView.showsUserLocation = true
                
            }
        }
        
        override func viewWillAppear(_ animated: Bool) {
            if CLLocationManager.locationServicesEnabled() {
                locationManager.startUpdatingLocation()
            }
        }
        
        override func viewWillDisappear(_ animated: Bool) {
            super.viewWillDisappear(animated)
            locationManager.stopUpdatingLocation()
        }
        
        // delegate methods
        
        var annotation: MKAnnotation?

        func locationManager(_ manager: CLLocationManager,
                             didUpdateLocations locations: [CLLocation]) {
            let location = locations[locations.count - 1]
            
            message.text =
                "Latitude: " + String(format: "%.4f", location.coordinate.latitude) +
                "\nLongitude: " +  String(format: "%.4f", location.coordinate.longitude) +
                "\nHorizontal Accuracy: " + String(format: "%.4f", location.horizontalAccuracy) + " M"

            mapView.setRegion(MKCoordinateRegion(center: location.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)), animated: true)

            // a region 2000m x 2000m
            //mapView.setRegion(MKCoordinateRegionMakeWithDistance(location.coordinate, 2000, 2000), animated: true)
            
            
            //mapView.addAnnotation(Place(location.coordinate, "You are here!"))
            if annotation != nil {
                mapView.removeAnnotation(annotation!)
            }
            let place = Place(location.coordinate, "You are here!")
            mapView.addAnnotation(place)
            annotation = place
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
        
    }

    class Place : NSObject, MKAnnotation {
        
        var coordinate: CLLocationCoordinate2D
        var title: String?
        var subtitle: String?
        
        init(_ coordinate: CLLocationCoordinate2D,
             _ title: String? = nil,
             _ subtitle: String? = nil) {
            self.coordinate = coordinate
            self.title = title
            self.subtitle = subtitle
        }


}

