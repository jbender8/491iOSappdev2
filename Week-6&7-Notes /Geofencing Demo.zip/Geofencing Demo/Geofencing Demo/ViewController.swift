//
//  ViewController.swift
//  Geofencing Demo
//
//  Created by Xiaoping Jia on 4/22/17.
//  Copyright © 2017 DePaul University. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var message: UILabel!
    @IBOutlet weak var notice: UILabel!
    
    let locationManager = CLLocationManager()
    
    
    let points = [
        (lat: 41.879553, lon: -87.624450, name: "The Art Institute of Chicago"),
        (lat: 41.882523, lon: -87.622162, name: "Millenium Park"),
        (lat: 41.875832, lon: -87.618974, name: "Buckingham Fountain"),
        (lat: 41.878168, lon: -87.627601, name: "DePaul/CDM"),
    ]
    
    var regions = [CLCircularRegion]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let status = locationManager.authorizationStatus
        if status == .denied || status == .restricted {
            message.text = "Location service not authorized"
        } else {
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.distanceFilter = 1 // meter
            locationManager.delegate = self
            locationManager.requestAlwaysAuthorization()
            
            //mapView.mapType = .standard
            //mapView.mapType = .satellite
            //mapView.mapType = .hybrid
            //mapView.mapType = .satelliteFlyover
            mapView.mapType = .hybridFlyover
            mapView.showsUserLocation = true
            mapView.showsBuildings = true
            
            if CLLocationManager.isMonitoringAvailable(for: CLCircularRegion.self) {
                for p in points {
                    let center = CLLocationCoordinate2D(latitude: p.lat, longitude: p.lon)
                    let region = CLCircularRegion(center: center, radius: 10, identifier: p.name)
                    region.notifyOnEntry = true
                    region.notifyOnExit = true
                    regions.append(region)
                }
            } else {
                showAlert(withTitle:"Error", message: "Geofencing is not supported on this device!")
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if CLLocationManager.locationServicesEnabled() {
            locationManager.startUpdatingLocation()
        }
        if CLLocationManager.isMonitoringAvailable(for: CLCircularRegion.self) &&
            !regions.isEmpty {
            for region in regions {
                locationManager.startMonitoring(for: region)
            }
        }
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        locationManager.stopUpdatingLocation()
        for region in regions {
            locationManager.stopMonitoring(for: region)
        }
    }
    
    // delegate methods
    
    var annotation: MKAnnotation?
    
    func locationManager(_ manager: CLLocationManager,
                         didUpdateLocations locations: [CLLocation]) {
        let location = locations[locations.count - 1]
        
        NSLog("(\(location.coordinate.latitude), \(location.coordinate.longitude))")
        //print(manager.monitoredRegions) //.count)
        
        message.text =
            "Latitude: " + String(format: "%.4f", location.coordinate.latitude) +
            "\nLongitude: " +  String(format: "%.4f", location.coordinate.longitude) +
            "\nHorizontal Accuracy: " + String(format: "%.4f", location.horizontalAccuracy) + " M"
        
        mapView.setRegion(MKCoordinateRegion(center: location.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)), animated: true)
        
        
        if mapView.isPitchEnabled {
            mapView.setCamera(MKMapCamera(lookingAtCenter: location.coordinate, fromDistance: 1000, pitch: 60, heading: 0), animated: true)
        }
        
        if annotation != nil {
            mapView.removeAnnotation(annotation!)
        }
        let place = Place(location.coordinate, "You are here!")
        mapView.addAnnotation(place)
        annotation = place
    }
    
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        NSLog("Enter region \(region)")
        notice.text = "Enter \(region.identifier)"
        
    }
    
    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        NSLog("Exit region \(region)")
        notice.text = "Exit \(region.identifier)"
    }
    
    func locationManager(_ manager: CLLocationManager, monitoringDidFailFor region: CLRegion?, withError error: Error) {
        NSLog("Error \(error)")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func showAlert(withTitle title: String?, message: String?) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
}

class Place : NSObject, MKAnnotation {
    
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    
    init(_ coordinate: CLLocationCoordinate2D,
         _ title: String? = nil,
         _ subtitle: String? = nil) {
        self.coordinate = coordinate
        self.title = title
        self.subtitle = subtitle
    }
}
