//
//  ViewController.swift
//  Location Demo - SB
//
//  Created by Xiaoping Jia on 3/26/21.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var message: UILabel!
    @IBOutlet weak var heading: UILabel!
    
    let locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let status = locationManager.authorizationStatus
        //print(status.rawValue)
        if status == .denied || status == .restricted {
          message.text = "Location service not authorized"
        } else {
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.distanceFilter = 1 // meter
            locationManager.delegate = self
            locationManager.requestWhenInUseAuthorization()
            
            // for significant-change location service
            //locationManager.requestAlwaysAuthorization()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if CLLocationManager.locationServicesEnabled() {
            locationManager.startUpdatingLocation()
            //locationManager.startMonitoringSignificantLocationChanges()
        }
        if CLLocationManager.headingAvailable() {
            locationManager.startUpdatingHeading()
            
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        locationManager.stopUpdatingLocation()
        //locationManager.stopMonitoringSignificantLocationChanges()
        locationManager.stopUpdatingHeading()
    }

    // delegate methods
    
    func locationManager(_ manager: CLLocationManager,
                         didUpdateLocations locations: [CLLocation]) {
        let location = locations[locations.count - 1]
        
        let text = [
            "Latitude: " + String(format: "%.4f", location.coordinate.latitude),
            "Longitude: " +  String(format: "%.4f", location.coordinate.longitude),
            "Horizontal Accuracy: " + String(format: "%.4f", location.horizontalAccuracy) + " m",
            "Altitude: " + String(format: "%.4f", location.altitude) + " m",
            "Floor: \(location.floor?.level ?? 0)",
            "Vertical Accuracy: " + String(format: "%.4f", location.verticalAccuracy) + " m",
            "Heading: " + String(format: "%.4fº", locationManager.heading ?? "No heading"),
            "Speed: " + String(format: "%.4f", location.speed) + " m/s",
            "Course: " + String(format: "%.4f", location.course) + "º",
        ]
        message.text = text.reduce("", { (lhs, rhs) -> String in lhs + "\n" + rhs } )
    }
    
    func locationManager(_ manager: CLLocationManager,
                         didUpdateHeading newHeading: CLHeading) {
        heading.text =
            "True Heading: " + String(format: "%.4f", newHeading.trueHeading) +
            "\nMagnetic Heading: " + String(format: "%.4f", newHeading.magneticHeading) +
            "\nHeading Accuracy: " + String(format: "%.4f", newHeading.headingAccuracy)
    }
    


}

