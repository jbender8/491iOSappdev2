//
//  ViewController.swift
//  Geocoding Demo
//
//  Created by Xiaoping Jia on 4/22/17.
//  Copyright © 2017 DePaul University. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {

    @IBOutlet weak var message: UILabel!
    @IBOutlet weak var mapView: MKMapView!
    
    let geocoder = CLGeocoder()
    
    var annotation: MKAnnotation?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func geocode(_ sender: UITextField) {
        if let address = sender.text {
            geocoder.geocodeAddressString(address) { (placemarks, error) in
                if let error = error {
                    NSLog("Error: \(error)")
                    return
                }
                if let placemarks = placemarks,
                    let placemark = placemarks.first,
                    let coordinate = placemark.location?.coordinate {
                    let text = [
                        "Latitude: " + String(format: "%.8f", coordinate.latitude),
                        "Longitude: " +  String(format: "%.8f", coordinate.longitude),
                        "ISO Country: \(placemark.isoCountryCode ?? "")",
                        "Country: \(placemark.country ?? "")",
                        "Postal code: \(placemark.postalCode ?? "")",
                        "Administrative Area: \(placemark.administrativeArea ?? "")",
                        "Sub-Administrative Area: \(placemark.subAdministrativeArea ?? "")",
                        "Locality: \(placemark.locality ?? "")",
                        "Sub-Locality: \(placemark.subLocality ?? "")",
                        "Thoroughfare: \(placemark.thoroughfare ?? "")",
                        "Sub-Thoroughfare: \(placemark.subThoroughfare ?? "")",
                        "Time Zone: \(placemark.timeZone?.description ?? "")"
                    ]
                    
                    self.message.text = text.reduce("", { (lhs, rhs) -> String in lhs + "\n" + rhs } )
                    
                    
                    self.mapView.setRegion(MKCoordinateRegion(center: coordinate, span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02)), animated: true)
                    
                    if self.annotation != nil {
                        self.mapView.removeAnnotation(self.annotation!)
                    }
                    let place = Place(coordinate, address)
                    self.mapView.addAnnotation(place)
                    self.annotation = place
                    
                    print("======")
                    if let addr = placemark.addressDictionary {
                        for (k,v) in addr {
                            print("\(k): \(v)")
                        }
                    }
                    print("======")
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    

}

class Place : NSObject, MKAnnotation {
    
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    
    init(_ coordinate: CLLocationCoordinate2D,
         _ title: String? = nil,
         _ subtitle: String? = nil) {
        self.coordinate = coordinate
        self.title = title
        self.subtitle = subtitle
    }
}

