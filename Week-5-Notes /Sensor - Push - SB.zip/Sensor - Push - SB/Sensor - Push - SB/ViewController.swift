//
//  ViewController.swift
//  Sensor - Push - SB
//
//  Created by Xiaoping Jia on 3/25/21.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {

    @IBOutlet weak var availability: UILabel!
    @IBOutlet weak var accelValue: UILabel!
    @IBOutlet weak var gyroValue: UILabel!
    @IBOutlet weak var magnetValue: UILabel!
    @IBOutlet weak var attitudeValue: UILabel!
    @IBOutlet weak var rotationValue: UILabel!
    @IBOutlet weak var gravityValue: UILabel!
    @IBOutlet weak var userAccelValue: UILabel!
    @IBOutlet weak var magFieldValue: UILabel!
    
    @IBOutlet weak var accelFreq: UILabel!
    @IBOutlet weak var gyroFreq: UILabel!
    @IBOutlet weak var magnetFreq: UILabel!
    @IBOutlet weak var motionFreq: UILabel!
    
    let motionManager = CMMotionManager() // must be declared as a property
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        var s = ""
        if motionManager.isAccelerometerAvailable {
            s += "A"
        }
        if motionManager.isGyroAvailable {
            s += "G"
        }
        if motionManager.isMagnetometerAvailable {
            s += "M"
        }
        if motionManager.isDeviceMotionAvailable {
            s += "D"
        }
        if s == "" {
            availability.text = "Motion sensors: none"
        } else {
            availability.text = "Motion sensors: " + s
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let queue = OperationQueue()
        if motionManager.isAccelerometerAvailable {
            let accelStart = Date()
            var accelCount = 0
            
            motionManager.accelerometerUpdateInterval = 1/10
            /* full syntax:
             motionManager.startAccelerometerUpdatesToQueue(queue, withHandler: {
             (data: CMAccelerometerData?, error: NSError?)  in ...
             })
             
             The following code use trailing closure
             */
            motionManager.startAccelerometerUpdates(to: queue) { data, error in
                //NSLog("In update handler")
                accelCount += 1
                let accel: String
                if let data = data {
                    accel = String(format: "x=%+6.3f y=%+6.3f z=%+6.3f",
                                   data.acceleration.x, data.acceleration.y, data.acceleration.z)
                } else {
                    accel = "No accelerometer data"
                }
                
                DispatchQueue.main.async {
                    self.accelValue.text = accel
                    
                    let elapsedTime = Date().timeIntervalSince(accelStart)
                    self.accelFreq.text = String(format: "%4.2fHz", Double(accelCount)/elapsedTime)
                }
            }
        } else {
            accelValue.text = "Accelerometer not available"
        }
        
        if motionManager.isGyroAvailable {
            let gyroStart = Date()
            var gyroCount = 0
            motionManager.gyroUpdateInterval = 1/10
            motionManager.startGyroUpdates(to: queue) { data, error in
                gyroCount += 1
                let gyro: String
                if let data = data {
                    gyro = String(format: "x=%+6.3f y=%+6.3f z=%+6.3f",
                                  data.rotationRate.x, data.rotationRate.y, data.rotationRate.z)
                } else {
                    gyro = "No gyroscope data"
                }
                DispatchQueue.main.async {
                    self.gyroValue.text = gyro
                    
                    let elapsedTime = Date().timeIntervalSince(gyroStart)
                    self.gyroFreq.text = String(format: "%4.2fHz", Double(gyroCount)/elapsedTime)
                }
            }
        } else {
            gyroValue.text = "Gyroscope not available"
        }
        
        if motionManager.isMagnetometerAvailable {
            let magnetStart = Date()
            var magnetCount = 0
            motionManager.magnetometerUpdateInterval = 1/10
            motionManager.startMagnetometerUpdates(to: queue) { data, error in
                magnetCount += 1
                let magnet: String
                if let data = data {
                    magnet = String(format: "x=%+6.3f y=%+6.3f z=%+6.3f",
                                    data.magneticField.x, data.magneticField.y, data.magneticField.z)
                } else {
                    magnet = "No magnetometer data"
                }
                DispatchQueue.main.async {
                    self.magnetValue.text = magnet
                    
                    let elapsedTime = Date().timeIntervalSince(magnetStart)
                    self.magnetFreq.text = String(format: "%4.2fHz", Double(magnetCount)/elapsedTime)
                }
            }
        } else {
            magnetValue.text = "Magnetometer not available"
        }
        
        if motionManager.isDeviceMotionAvailable {
            let motionStart = Date()
            var motionCount = 0
            motionManager.deviceMotionUpdateInterval = 1/10
            motionManager.startDeviceMotionUpdates(using: .xArbitraryCorrectedZVertical, to: queue)
            { data, error in
                motionCount += 1
                let attitude, rotation, gravity, uaccel, magfield: String
                if let data = data {
                    attitude = String(format: "roll=%+6.3f pitch=%+6.3f yaw=%+6.3f",
                                      data.attitude.roll, data.attitude.pitch, data.attitude.yaw)
                    rotation = String(format: "x=%+6.3f y=%+6.3f z=%+6.3f",
                                      data.rotationRate.x, data.rotationRate.y, data.rotationRate.z)
                    gravity = String(format: "x=%+6.3f y=%+6.3f z=%+6.3f",
                                     data.gravity.x, data.gravity.y, data.gravity.z)
                    uaccel = String(format: "x=%+6.3f y=%+6.3f z=%+6.3f",
                                    data.userAcceleration.x, data.userAcceleration.y, data.userAcceleration.z)
                    magfield = String(format: "x=%+6.3f y=%+6.3f z=%+6.3f\naccuracy=%d",
                                      data.magneticField.field.x, data.magneticField.field.y, data.magneticField.field.z,
                                      data.magneticField.accuracy.rawValue)
                } else {
                    attitude = "No device motion data"
                    rotation = "No device motion data"
                    gravity = "No device motion data"
                    uaccel = "No device motion data"
                    magfield = "No device motion data"
                }
                
                DispatchQueue.main.async {
                    self.attitudeValue.text = attitude
                    self.rotationValue.text = rotation
                    self.gravityValue.text = gravity
                    self.userAccelValue.text = uaccel
                    self.magFieldValue.text = magfield
                    
                    let elapsedTime = Date().timeIntervalSince(motionStart)
                    self.motionFreq.text = String(format: "%4.2fHz", Double(motionCount)/elapsedTime)
                }
            }
        } else {
            attitudeValue.text = "Device motion not available"
            rotationValue.text = "Device motion not available"
            gravityValue.text = "Device motion not available"
            userAccelValue.text = "Device motion not available"
            magFieldValue.text = "Device motion not available"
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if motionManager.isAccelerometerActive {
            motionManager.stopAccelerometerUpdates()
        }
        if motionManager.isGyroActive {
            motionManager.stopGyroUpdates()
        }
        if motionManager.isMagnetometerActive {
            motionManager.stopMagnetometerUpdates()
        }
        if motionManager.isDeviceMotionActive {
            motionManager.stopDeviceMotionUpdates()
        }
    }
    


}

