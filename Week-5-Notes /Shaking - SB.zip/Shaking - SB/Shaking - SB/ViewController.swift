//
//  ViewController.swift
//  Shaking - SB
//
//  Created by Xiaoping Jia on 3/25/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    override var canBecomeFirstResponder: Bool { return true }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        becomeFirstResponder()
    }
    
    override func motionBegan(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        NSLog("motionBegan")
    }
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        NSLog("motionEnded")
        if motion == .motionShake {
            label.text = "Shake\ndetected!"
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(3)) {
                self.label.text = ""
            }
        }
    }
    
    override func motionCancelled(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        NSLog("motionCanclled")
    }
    
}

