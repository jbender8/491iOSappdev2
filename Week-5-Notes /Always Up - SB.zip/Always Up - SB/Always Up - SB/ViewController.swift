//
//  ViewController.swift
//  Always Up - SB
//
//  Created by Xiaoping Jia on 3/26/21.
//

import UIKit
import CoreMotion
class ViewController: UIViewController {

    @IBOutlet weak var arrow: UpArrow!
    
    let motionManager = CMMotionManager() // must be declared as a property
    let updateFrequency = 60.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if motionManager.isDeviceMotionAvailable {
            motionManager.deviceMotionUpdateInterval = 1/updateFrequency
            motionManager.startDeviceMotionUpdates(to: .main) { data, error in
                if let gravity = data?.gravity {
                    let rotation = atan2(gravity.x, gravity.y) - Double.pi
                    self.arrow.transform = CGAffineTransform(rotationAngle: CGFloat(rotation))
                }
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if motionManager.isDeviceMotionActive {
            motionManager.stopDeviceMotionUpdates()
        }
    }

    override var shouldAutorotate: Bool { return false }


}

