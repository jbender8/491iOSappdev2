//
//  UpArrow.swift
//  Always Up - SB
//
//  Created by Xiaoping Jia on 3/26/21.
//
//

import UIKit

class UpArrow: UIView {

    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        if let context = UIGraphicsGetCurrentContext() {
            let tip = CGPoint(x: bounds.width / 2, y: bounds.height * 0.1)
            let center = CGPoint(x: bounds.width / 2, y: bounds.height / 2)
            let left = CGPoint(x: bounds.width * 0.1, y: bounds.height * 0.9)
            let right = CGPoint(x: bounds.width * 0.9, y: bounds.height * 0.9)
            
            context.move(to: tip)
            context.addLine(to: left)
            context.addLine(to: center)
            context.addLine(to: right)
            context.closePath()
            
            context.setFillColor(UIColor.green.cgColor)
            context.fillPath()
            
        }
        
        
    }
    

}
