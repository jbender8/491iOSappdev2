//
//  ViewController.swift
//  Orientation - SB
//
//  Created by Xiaoping Jia on 3/25/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    
    var observer : Any?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        UIDevice.current.beginGeneratingDeviceOrientationNotifications()
        observer = NotificationCenter.default.addObserver(
            forName: UIDevice.orientationDidChangeNotification,
            object: nil, queue: nil) { notification in
                let orientation = UIDevice.current.orientation
                // Use the orientation value in your app.
                var message = "Orientation: "
                switch orientation {
                case .unknown: message += "Unknown\n"
                case .portrait: message += "Portrait\n"
                case .portraitUpsideDown: message += "Portrait Upside Down\n"
                case .landscapeLeft: message += "Landscape Left\n"
                case .landscapeRight: message += "Landscape Right\n"
                case .faceUp: message += "Face Up\n"
                case .faceDown: message += "Face Down\n"
                @unknown default:
                    print("Unknown") 
                }
                if orientation.isPortrait {
                    message += "Is Portrait\n"
                } else if orientation.isLandscape {
                    message += "Is Landscape\n"
                } else if orientation.isFlat {
                    message += "Is Flat\n"
                }
                message += "Raw value: \(orientation.rawValue)"
                self.label.text = message
        }
                
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        UIDevice.current.endGeneratingDeviceOrientationNotifications()
        NotificationCenter.default.removeObserver(self.observer!)
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .all
    }
    
}

