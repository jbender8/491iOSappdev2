//
//  ViewController.swift
//  Compass Demo - SB
//
//  Created by Xiaoping Jia on 3/26/21.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {

    
    @IBOutlet weak var compassView: CompassView!
    
    let motionManager = CMMotionManager() // must be declared as a property

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(_ animated: Bool) {
        if motionManager.isDeviceMotionAvailable {
            motionManager.deviceMotionUpdateInterval = 1/10
            motionManager.startDeviceMotionUpdates(using: .xTrueNorthZVertical, to: .main) { data, error in
                if let mdata = data?.magneticField.field {
                    //self.compassView.angle = CGFloat(atan2(mdata.x, mdata.y))
                    //self.compassView.setNeedsDisplay()
                    
                    self.compassView.transform =
                        CGAffineTransform(rotationAngle: CGFloat(atan2(mdata.x, mdata.y)))
                }
            }
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if motionManager.isDeviceMotionActive {
            motionManager.stopDeviceMotionUpdates()
        }
    }

    override var shouldAutorotate: Bool { return false }
    

}

