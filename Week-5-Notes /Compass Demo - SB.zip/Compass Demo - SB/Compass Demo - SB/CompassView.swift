//
//  CompassView.swift
// Compass Demo - SB
//
//  Created by Xiaoping Jia on 3/26/21.
//

import UIKit

class CompassView: UIView {
    
    //var angle: CGFloat = 0 // the angle between Y and North
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        if let context = UIGraphicsGetCurrentContext() {
            context.fill(bounds)
            
            context.setShouldAntialias(true)
            context.setStrokeColor(UIColor.white.cgColor)
            context.setLineWidth(2)
            
            let d: CGFloat = 10
            let radius = min(bounds.width, bounds.height) / 2 - 20
            context.strokeEllipse(in: CGRect(x: bounds.width / 2 - radius, y: bounds.height / 2 - radius, width: radius * 2, height: radius * 2))
            
            context.setLineWidth(1)
            context.translateBy(x: bounds.width / 2, y: bounds.height / 2) // move the origin to the center
            context.rotate(by: CGFloat(Double.pi)) // turn canvas upside-down
            //context.rotate(by: angle) // turn to face North
            
            let path1 = CGMutablePath()
            path1.move(to: CGPoint(x: 0, y: 0))
            path1.addLine(to: CGPoint(x: d, y: d))
            path1.addLine(to:CGPoint(x: 0, y: radius - 2 * d))
            path1.closeSubpath()
            let path2 = CGMutablePath()
            path2.move(to: CGPoint(x: 0, y: 0))
            path2.addLine(to: CGPoint(x: -d, y: d))
            path2.addLine(to: CGPoint(x: 0, y: radius - 2 * d))
            path2.closeSubpath()
            
            let textStyle = NSMutableParagraphStyle()
            textStyle.alignment = .center
            let textAttr: [NSAttributedString.Key : Any]  = [
                NSAttributedString.Key.foregroundColor : UIColor.white,
                NSAttributedString.Key.paragraphStyle: textStyle,
            ]
            let labels = [ "N", "E", "S", "W" ]
            let dr = CGFloat(Double.pi / 6)
            for i in 0 ..< 12 {
                context.setFillColor(UIColor.white.cgColor)
                "\(i * 30)".draw(in: CGRect(x: -20, y: radius - 16, width: 40, height: 20), withAttributes: textAttr)
                
                if i % 3 == 0 {
                    labels[i / 3].draw(in: CGRect(x: -10, y: radius + 6, width: 20, height: 20), withAttributes: textAttr)
                    
                    context.setFillColor(UIColor.gray.cgColor)
                    context.addPath(path1)
                    context.fillPath()
                    context.setFillColor(i == 0 ? UIColor.red.cgColor : UIColor.yellow.cgColor)
                    context.addPath(path2)
                    context.fillPath()
                }
                context.rotate(by: dr)
            }
        
        }
        
    }
    

}
