//
//  AccelerometerFilter.swift
//  Accelerometer Graph - SB
//
//  Created by Xiaoping Jia on 3/25/21.
//
//

import UIKit
import CoreMotion

class AccelerometerFilter {

    var x = 0.0, y = 0.0, z = 0.0
    var adaptive = false
    
    var filterConstant: Double = 0.0
    var lastX = 0.0, lastY = 0.0, lastZ = 0.0
    
    func addAcceleration(_ accel: CMAcceleration ) {
        x = accel.x
        y = accel.y
        z = accel.z
    }
    
    func name() -> String {
        return "You should not see this"
    }
    
}

func norm(_ x: Double, _ y: Double, _ z: Double) -> Double {
    return sqrt(x * x + y * y + z * z);
}

func clamp(_ v: Double, _ min: Double, _ max: Double) -> Double {
    if v > max {
        return max;
    } else if v < min {
        return min;
    } else {
        return v;
    }
}

let AccelerometerMinStep				= 0.02
let AccelerometerNoiseAttenuation		= 3.0

// See http://en.wikipedia.org/wiki/Low-pass_filter for details low pass filtering
class LowpassFilter : AccelerometerFilter {
    
    init(rate: Double,  cutoffFrequency freq:Double) {
        super.init()

        let dt = 1.0 / rate;
        let RC = 1.0 / freq;
        filterConstant = dt / (dt + RC);
    }
    
    override func addAcceleration(_ accel: CMAcceleration ) {
        var alpha = filterConstant;
    
        if adaptive {
            let d = clamp(fabs(norm(x, y, z) - norm(accel.x, accel.y, accel.z)) / AccelerometerMinStep - 1.0, 0.0, 1.0);
            alpha = (1.0 - d) * filterConstant / AccelerometerNoiseAttenuation + d * filterConstant;
        }
    
        x = accel.x * alpha + x * (1.0 - alpha);
        y = accel.y * alpha + y * (1.0 - alpha);
        z = accel.z * alpha + z * (1.0 - alpha);
    }
    
    override func name() -> String {
        return adaptive ? "Adaptive Lowpass Filter" : "Lowpass Filter"
    }
}

// See http://en.wikipedia.org/wiki/High-pass_filter for details on high pass filtering
class HighpassFilter: AccelerometerFilter {

    init(rate: Double,  cutoffFrequency freq:Double) {
        super.init()

        let dt = 1.0 / rate;
        let RC = 1.0 / freq;
        filterConstant = RC / (dt + RC)
    }
    
    override func addAcceleration(_ accel: CMAcceleration ) {
        var alpha = filterConstant;
    
        if adaptive {
            let d = clamp(fabs(norm(x, y, z) - norm(accel.x, accel.y, accel.z)) / AccelerometerMinStep - 1.0, 0.0, 1.0);
            alpha = d * filterConstant / AccelerometerNoiseAttenuation + (1.0 - d) * filterConstant;
        }
        
        x = alpha * (x + accel.x - lastX);
        y = alpha * (y + accel.y - lastY);
        z = alpha * (z + accel.z - lastZ);
        
        lastX = accel.x;
        lastY = accel.y;
        lastZ = accel.z;
    }
    
    override func name() -> String {
        return adaptive ? "Adaptive Highpass Filter" : "Highpass Filter"
    }

}
