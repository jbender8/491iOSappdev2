//
//  GraphView.swift
//  Accelerometer Graph - SB
//
//  Created by Xiaoping Jia on 3/25/21.
//
//

import UIKit

class GraphView: UIView {
    
    var N: Int = 32
    var index = 0
    var count = 0
    var xhistory, yhistory, zhistory: [Double]!
    
    func setHistorySize(_ size: Int) {
        N = size
        xhistory = [Double](repeating: 0.0, count: N)
        yhistory = [Double](repeating: 0.0, count: N)
        zhistory = [Double](repeating: 0.0, count: N)
        index = N - 1
        count = 0
    }
    
    func add(_ x: Double, _ y: Double, _ z: Double) {
        xhistory[index] = x;
        yhistory[index] = y;
        zhistory[index] = z;
        index -= 1
        if index < 0 {
            index = N - 1
        }
        if count < N {
            count += 1
        }
        
        setNeedsDisplay()
    }
    
    func reset() {
        index = N - 1
        count = 0
    }
    
    let graphBackgroundColor = UIColor.lightGray.cgColor
    let graphLineColor = UIColor.darkGray.cgColor
    let graphXColor = UIColor.red.cgColor
    let graphYColor = UIColor.green.cgColor
    let graphZColor = UIColor.blue.cgColor
    
    // Only override draw: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        if let context = UIGraphicsGetCurrentContext() {
            
            // Fill in the background
            context.setFillColor(graphBackgroundColor);
            context.fill(self.bounds);
            
            let hscale: CGFloat = 4
            let vscale: CGFloat = 32
            let hoffset: CGFloat = 32
            context.translateBy(x: 0.0, y: 56.0)
            
            drawGridlines(context, hoffset, CGFloat(N) * hscale)
            
            if  count > 0 {
                // X
                var j = (index + 1) % N
                context.move(to: CGPoint(x: 0, y: -CGFloat(xhistory[j]) * vscale))
                for i in 0 ..< count - 1 {
                    context.addLine(to: CGPoint(x: CGFloat(i + 1) * hscale + hoffset, y: -CGFloat(xhistory[j]) * vscale))
                    j = (j + 1) % N
                }
                context.setStrokeColor(graphXColor)
                context.strokePath()
                
                // Y
                j = (index + 1) % N
                context.move(to: CGPoint(x: 0, y: -CGFloat(yhistory[j]) * vscale))
                for i in 0 ..< count - 1 {
                    context.addLine(to: CGPoint(x: CGFloat(i + 1) * hscale + hoffset, y: -CGFloat(yhistory[j]) * vscale))
                    j = (j + 1) % N
                }
                context.setStrokeColor(graphYColor)
                context.strokePath()
                
                // Z
                j = (index + 1) % N
                context.move(to: CGPoint(x: 0, y: -CGFloat(zhistory[j]) * vscale))
                for i in 0 ..< count - 1 {
                    context.addLine(to: CGPoint(x: CGFloat(i + 1) * hscale + hoffset, y: -CGFloat(zhistory[j]) * vscale))
                    j = (j + 1) % N
                }
                context.setStrokeColor(graphZColor)
                context.strokePath()
            }
        }
    }

    func drawGridlines(_ context: CGContext, _ x: CGFloat, _ width: CGFloat) {
        let textStyle = NSMutableParagraphStyle.default.mutableCopy() as! NSMutableParagraphStyle
        textStyle.alignment = NSTextAlignment.right
        let textFontAttributes = [
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12),
            NSAttributedString.Key.foregroundColor: UIColor.white,
            NSAttributedString.Key.paragraphStyle: textStyle
        ]
        
        for i: CGFloat in stride(from: +1.5, through: -1.5, by: -0.5) {
            let y = -i * 32 as CGFloat
            context.move(to: CGPoint(x: x, y: y));
            context.addLine(to: CGPoint(x: x + width, y: y));
            
            let label = String(format: "%+.1f", i)
            label.draw(in: CGRect(x: 2, y: y - 8, width: 28, height: 16), withAttributes: textFontAttributes)
        }
        context.setStrokeColor(graphLineColor);
        context.strokePath();
    }
    
    
}
