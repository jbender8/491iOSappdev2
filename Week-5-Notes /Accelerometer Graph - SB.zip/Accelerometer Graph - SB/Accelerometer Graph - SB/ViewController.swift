//
//  ViewController.swift
//  Accelerometer Graph - SB
//
//  Created by Xiaoping Jia on 3/25/21.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {
    
    @IBOutlet weak var topView: GraphView!
    @IBOutlet weak var middleView: GraphView!
    @IBOutlet weak var bottomView: GraphView!
    
    @IBOutlet weak var accelValue: UILabel!
    @IBOutlet weak var motionValue: UILabel!
    
    let updateFrequency = 10.0 // 60.0
    var paused = false
    var useAdaptive = false
    var motionGravity = true
    
    var filters: [ AccelerometerFilter ]!
    var filter: AccelerometerFilter?
    
    let motionManager = CMMotionManager() // must be declared as a property
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        filters = [
            LowpassFilter(rate: updateFrequency, cutoffFrequency:5.0),
            HighpassFilter(rate: updateFrequency, cutoffFrequency:5.0)
        ]
        
        topView.setHistorySize(128)
        middleView.setHistorySize(128)
        bottomView.setHistorySize(128)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if motionManager.isAccelerometerAvailable {
            let accelStart = Date()
            var accelCount = 0
            motionManager.accelerometerUpdateInterval = 1/updateFrequency
            motionManager.startAccelerometerUpdates(to: .main) { data, error in
                accelCount += 1
                let accelText: String
                if let data = data {
                    if !self.paused {
                        self.topView.add(data.acceleration.x, data.acceleration.y, data.acceleration.z)
                        if let filter = self.filter {
                            filter.addAcceleration(data.acceleration)
                            self.middleView.add(filter.x, filter.y, filter.z)
                        } else {
                            self.middleView.add(data.acceleration.x, data.acceleration.y, data.acceleration.z)
                        }
                        
                        let elapsedTime = Date().timeIntervalSince(accelStart)
                        accelText = String(format: "x=%+.3f y=%+.3f z=%+.3f @ %.2fHz",
                                       data.acceleration.x, data.acceleration.y, data.acceleration.z,
                                       Double(accelCount)/elapsedTime)
                    } else {
                        accelText = "Paused"
                    }
                } else {
                    accelText = "No accelerometer data"
                }
                self.accelValue.text = accelText
            }
        }
        
        if motionManager.isDeviceMotionAvailable {
            let motionStart = Date()
            var motionCount = 0
            motionManager.deviceMotionUpdateInterval = 1/updateFrequency
            motionManager.startDeviceMotionUpdates(to: .main) { data, error in
                motionCount += 1
                let motionText: String
                if let data = data {
                    if !self.paused {
                        let acceleration = self.motionGravity ? data.gravity : data.userAcceleration
                        self.bottomView.add(acceleration.x, acceleration.y, acceleration.z)
                        let elapsedTime = Date().timeIntervalSince(motionStart)
                        motionText = String(format: "x=%+.3f y=%+.3f z=%+.3f @ %.2fHz",
                                            acceleration.x, acceleration.y, acceleration.z,
                                            Double(motionCount)/elapsedTime)
                    } else {
                        motionText = "Paused"
                    }
                } else {
                    motionText = "No device motion data"
                }
                self.motionValue.text = motionText
            }
        }
    }
    
    @IBAction func filterSelect(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 1, 2:
            filter = filters[sender.selectedSegmentIndex - 1]
            filter?.adaptive = useAdaptive
        default:
            filter = nil
        }
        middleView.reset()
    }
    
    @IBAction func adaptiveSelect(_ sender: UISegmentedControl) {
        useAdaptive = sender.selectedSegmentIndex == 1
        filter?.adaptive = useAdaptive
        middleView.reset()
    }

    @IBAction func motionSelect(_ sender: UISegmentedControl) {
        motionGravity = sender.selectedSegmentIndex == 0
        bottomView.reset()
    }
    
    @IBAction func pauseOrResume(_ sender: UIButton) {
        paused = !paused
        sender.setTitle(paused ? "Resume" : "Pause", for: .normal)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if motionManager.isAccelerometerActive {
            motionManager.stopAccelerometerUpdates()
        }
        if motionManager.isDeviceMotionActive {
            motionManager.stopDeviceMotionUpdates()
        }

    }


}

