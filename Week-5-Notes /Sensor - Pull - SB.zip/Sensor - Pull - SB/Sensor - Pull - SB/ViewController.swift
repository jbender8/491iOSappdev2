//
//  ViewController.swift
//  Sensor - Pull - SB
//
//  Created by Xiaoping Jia on 3/25/21.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {

    
    @IBOutlet weak var availability: UILabel!
    @IBOutlet weak var accelValue: UILabel!
    @IBOutlet weak var gyroValue: UILabel!
    @IBOutlet weak var magnetValue: UILabel!
    @IBOutlet weak var attitudeValue: UILabel!
    @IBOutlet weak var rotationValue: UILabel!
    @IBOutlet weak var gravityValue: UILabel!
    @IBOutlet weak var userAccelValue: UILabel!
    @IBOutlet weak var magFieldValue: UILabel!
    
    @IBOutlet weak var accelFreq: UILabel!
    @IBOutlet weak var gyroFreq: UILabel!
    @IBOutlet weak var magnetFreq: UILabel!
    @IBOutlet weak var motionFreq: UILabel!
    
    let motionManager = CMMotionManager() // must be declared as a property
    var timer: Timer?
    var timeStart = Date()
    var count = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        var s = ""
        if motionManager.isAccelerometerAvailable {
            s += "A"
        }
        if motionManager.isGyroAvailable {
            s += "G"
        }
        if motionManager.isMagnetometerAvailable {
            s += "M"
        }
        if motionManager.isDeviceMotionAvailable {
            s += "D"
        }
        if s == "" {
            availability.text = "Motion sensors: none"
        } else {
            availability.text = "Motion sensors: " + s
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if motionManager.isAccelerometerAvailable {
            motionManager.accelerometerUpdateInterval = 1/10
            motionManager.startAccelerometerUpdates()
        } else {
            accelValue.text = "Accelerometer not available"
        }
        if motionManager.isGyroAvailable {
            motionManager.gyroUpdateInterval = 1/10
            motionManager.startGyroUpdates()
        } else {
            gyroValue.text = "Gyroscope not available"
        }
        if motionManager.isMagnetometerAvailable {
            motionManager.magnetometerUpdateInterval = 1/10
            motionManager.startMagnetometerUpdates()
        } else {
            magnetValue.text = "Magnetometer not available"
        }
        if motionManager.isDeviceMotionAvailable {
            motionManager.deviceMotionUpdateInterval = 1/10
            if motionManager.isMagnetometerAvailable {
                motionManager.startDeviceMotionUpdates(using: .xTrueNorthZVertical)
            } else {
                motionManager.startDeviceMotionUpdates(using: .xArbitraryZVertical)
            }
        } else {
            attitudeValue.text = "Device motion not available"
            rotationValue.text = "Device motion not available"
            gravityValue.text = "Device motion not available"
            userAccelValue.text = "Device motion not available"
            magFieldValue.text = "Device motion not available"
        }
        
        timeStart = Date()
        count = 0
        timer = Timer.scheduledTimer(timeInterval: 1/10, target: self,
                                    selector: #selector(handleSensors),
                                    userInfo: nil, repeats: true)
        
    }
    
    @objc func handleSensors(_ timer: Timer) {
        count += 1
        let elapsedTime = Date().timeIntervalSince(timeStart)
        let freq = Double(count)/elapsedTime
        if motionManager.isAccelerometerAvailable {
            let accel: String
            if let data = motionManager.accelerometerData {
                accel = String(format: "x=%+6.3f y=%+6.3f z=%+6.3f",
                                data.acceleration.x, data.acceleration.y, data.acceleration.z)
            } else {
                accel = "No accelerometer data"
            }

            self.accelValue.text = accel
            self.accelFreq.text = String(format: "%4.2fHz", freq)
        }
        
        if motionManager.isGyroAvailable {
            let gyro: String
            if let data = motionManager.gyroData {
                gyro = String(format: "x=%+6.3f y=%+6.3f z=%+6.3f",
                              data.rotationRate.x, data.rotationRate.y, data.rotationRate.z)
            } else {
                gyro = "No gyroscope data"
            }
            
            self.gyroValue.text = gyro
            self.gyroFreq.text = String(format: "%4.2fHz", freq)
        }
        
        if motionManager.isMagnetometerAvailable {
            let magnet: String
            if let data = motionManager.magnetometerData {
                magnet = String(format: "x=%+6.3f y=%+6.3f z=%+6.3f",
                                data.magneticField.x, data.magneticField.y, data.magneticField.z)
            } else {
                magnet = "No magnetometer data"
            }
            
            self.magnetValue.text = magnet
            self.magnetFreq.text = String(format: "%4.2fHz", freq)
        }
        
        if motionManager.isDeviceMotionAvailable {
            let attitude, rotation, gravity, uaccel, magfield: String
            if let data = motionManager.deviceMotion {
                attitude = String(format: "roll=%+6.3f pitch=%+6.3f yaw=%+6.3f",
                                  data.attitude.roll, data.attitude.pitch, data.attitude.yaw)
                rotation = String(format: "x=%+6.3f y=%+6.3f z=%+6.3f",
                                  data.rotationRate.x, data.rotationRate.y, data.rotationRate.z)
                gravity = String(format: "x=%+6.3f y=%+6.3f z=%+6.3f",
                                 data.gravity.x, data.gravity.y, data.gravity.z)
                uaccel = String(format: "x=%+6.3f y=%+6.3f z=%+6.3f",
                                data.userAcceleration.x, data.userAcceleration.y, data.userAcceleration.z)
                magfield = String(format: "x=%+6.3f y=%+6.3f z=%+6.3f\naccuracy=%d",
                                  data.magneticField.field.x, data.magneticField.field.y, data.magneticField.field.z,
                                  data.magneticField.accuracy.rawValue)
            } else {
                attitude = "No device motion data"
                rotation = "No device motion data"
                gravity = "No device motion data"
                uaccel = "No device motion data"
                magfield = "No device motion data"
            }
                
            self.attitudeValue.text = attitude
            self.rotationValue.text = rotation
            self.gravityValue.text = gravity
            self.userAccelValue.text = uaccel
            self.magFieldValue.text = magfield
            
            self.motionFreq.text = String(format: "%4.2fHz", freq)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if motionManager.isAccelerometerActive {
            motionManager.stopAccelerometerUpdates()
        }
        if motionManager.isGyroActive {
            motionManager.stopGyroUpdates()
        }
        if motionManager.isMagnetometerActive {
            motionManager.stopMagnetometerUpdates()
        }
        if motionManager.isDeviceMotionActive {
            motionManager.stopDeviceMotionUpdates()
        }
        timer?.invalidate()
    }
    
}

