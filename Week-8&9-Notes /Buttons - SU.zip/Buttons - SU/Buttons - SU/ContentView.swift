//
//  ContentView.swift
//  Buttons - SU
//
//  Created by Xiaoping Jia on 12/20/19.
//  Copyright © 2019 DePaul University. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    let labels = [ "Button 1", "Button 2" ]
    
    @State var message = "Hello State!"
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20.0) {
            Text(message)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            Button(action: {
                message = "Button 1 pressed"
            }) {
                Text("Button 1")
            }
            Button(action: {
                message = "Button 2 pressed"
            }) {
                Text("Button 2")
            }
            
            /*
            ForEach (labels, id: \.self) { label in
                Button(action:  {
                    message = "\(label) pressed"
                }) {
                    Text(label)
                }
            }
             */
            Spacer()
        }
        .padding([.top, .leading, .trailing])
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
