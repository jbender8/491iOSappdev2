//
//  ContentView.swift
//  My Home - Env - SU
//
//  Created by Xiaoping Jia on 3/7/21.
//

import SwiftUI

class Room : Identifiable, ObservableObject {
    init(_ name: String) {
        self.name = name
    }
    let id: UUID = .init()
    var name : String
    @Published var lightsOn = false
}

class House : ObservableObject {
    init(_ name: String, rooms: [Room]) {
        self.name = name
        self.rooms = rooms
    }
    var name : String
    @Published var rooms : [Room]
    @Published var temp : Double = 70
    
}

let myHome = House("My Home",
                   rooms: [ Room("Living Room"),
                            Room("Study Room"),
                            Room("Dining Room") ])

struct ContentView: View {
    @EnvironmentObject var house : House
    
    var body: some View {
        VStack {
            Text(house.name).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .padding()
            HStack {
                Text(String(format: "Temp: %.1fºF", house.temp))
                Slider(value: $house.temp, in: 40...90).padding(.leading)
            }.padding()
            Spacer()
            Group {
                Text("Room Controls").font(.title2).padding()
                List(house.rooms) { room in
                    RoomControlView(room: room)
                }
            }
            Divider()
            Group {
                Text("Rooms").font(.title2).padding()
                List(house.rooms) { room in
                    RoomView(room: room)
                }
            }
            Spacer()
        }
        
    }
}

struct RoomControlView: View {
    @EnvironmentObject var house : House
    @ObservedObject var room : Room
    
    var body: some View {
        HStack {
            Text(room.name)
            Spacer()
            Toggle("Lights", isOn: $room.lightsOn)
        }.padding()
    }
    
}

struct RoomView: View {
    @EnvironmentObject var house : House
    @ObservedObject var room : Room
    
    var body: some View {
        HStack {
            Text(room.name)
            Spacer()
            Text(String(format: "Temp: %.1fºF", house.temp))
            Spacer()
            Text(room.lightsOn ? "Lights On" : "Lights Off")
        }.padding().background(room.lightsOn ? Color.yellow : Color.gray)
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(myHome)
    }
}
