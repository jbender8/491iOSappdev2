//
//  My_Home___Env___SUApp.swift
//  My Home - Env - SU
//
//  Created by Xiaoping Jia on 3/7/21.
//

import SwiftUI

@main
struct My_Home___Env___SUApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(myHome)
        }
    }
}
