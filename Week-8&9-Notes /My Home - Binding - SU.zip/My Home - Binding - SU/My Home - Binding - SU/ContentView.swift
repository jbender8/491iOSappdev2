//
//  ContentView.swift
//  My Home - Binding - SU
//
//  Created by Xiaoping Jia on 3/7/21.
//

import SwiftUI

struct Room {
    var name : String
    var lightsOn = false
}

struct ContentView: View {
    
    @State private var livingRoom = Room(name: "Living Room")
    @State private var studyRoom = Room(name: "Study Room")
    @State private var diningRoom = Room(name: "Dining Room")
    
    var body: some View {
        VStack {
            Text("My Home").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .padding()
            Group {
                RoomControlView(room: $livingRoom)
                RoomControlView(room: $studyRoom)
                RoomControlView(room: $diningRoom)
            }
            Divider()
            Group {
                RoomView(room: $livingRoom)
                RoomView(room: $studyRoom)
                RoomView(room: $diningRoom)
            }
            Spacer()
        }
    }
}

struct RoomControlView: View {
    
    @Binding var room : Room
    
    var body: some View {
        HStack {
            Text(room.name)
            Spacer()
            Text("Lights")
            Toggle("Lights", isOn: $room.lightsOn).labelsHidden()
        }.padding()
    }
    
}

struct RoomView: View {
    
    @Binding var room : Room
    
    var body: some View {
        HStack {
            Text(room.name)
            Spacer()
            Text(room.lightsOn ? "Lights On" : "Lights Off")
        }.padding().background(room.lightsOn ? Color.yellow : Color.gray)
    }
    
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
