//
//  My_Home___Binding___SUApp.swift
//  My Home - Binding - SU
//
//  Created by Xiaoping Jia on 3/7/21.
//

import SwiftUI

@main
struct My_Home___Binding___SUApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
