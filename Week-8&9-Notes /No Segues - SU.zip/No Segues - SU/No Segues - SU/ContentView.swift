//
//  ContentView.swift
//  No Segues - SU
//
//  Created by Xiaoping Jia on 3/6/21.
//

import SwiftUI

struct ContentView: View {
    
    enum Page: String {
        case Blue = "Blue"
        case Yellow = "Yellow"
        case Green = "Green"
    }
    
    @State private var currentPage = Page.Blue
    
    var pageColor : Color {
        switch currentPage{
        case .Blue:
            //return Color.blue
            return Color(UIColor.cyan)
        case .Yellow:
            return Color.yellow
        case .Green:
            return Color.green
        }
    }
    
    @State private var message = ""
    
    @State private var messageToNextPage : String?
    
    var body: some View {
        ZStack {
            pageColor.ignoresSafeArea()
            if currentPage == .Blue {
                VStack {
                    Text("Hello, \(currentPage.rawValue) Page!\n\(messageToNextPage ?? "")")
                        .padding()
                    HStack {
                        Text("Type a message")
                        TextField("Type a message here", text: $message, onCommit:  {
                            UIApplication.shared.endEditing()
                        }).textFieldStyle(RoundedBorderTextFieldStyle())
                    }.padding()
                    Spacer()
                }.toolbar(content: {
                    ToolbarItem(placement: .bottomBar) {
                        Button(action: {
                            messageToNextPage = "Message from \(currentPage.rawValue) Page\n\(message)"
                            currentPage = .Yellow
                        }) {
                           Text("To Yellow")
                        }
                    }
                })
            } else if currentPage == .Yellow {
                VStack {
                    Text("Hello, \(currentPage.rawValue) Page!\n\(messageToNextPage ?? "")")
                        .padding()
                    HStack {
                        Text("Type a message")
                        TextField("Type a message here", text: $message, onCommit:  {
                            UIApplication.shared.endEditing()
                        }).textFieldStyle(RoundedBorderTextFieldStyle())
                    }.padding()
                    Spacer()
                }.toolbar(content: {
                    ToolbarItemGroup(placement: .bottomBar) {
                        Button(action: {
                            messageToNextPage = "Message from \(currentPage.rawValue) Page\n\(message)"
                            currentPage = .Blue
                        }) {
                           Text("To Blue")
                        }
                        Button(action: {
                            messageToNextPage = "Message from \(currentPage.rawValue) Page\n\(message)"
                            currentPage = .Green
                        }) {
                           Text("To Green")
                        }
                    }
                })
            } else {
                VStack {
                    Text("Hello, \(currentPage.rawValue) Page!\n\(messageToNextPage ?? "")")
                        .padding()
                    HStack {
                        Text("Type a message")
                        TextField("Type a message here", text: $message, onCommit:  {
                            UIApplication.shared.endEditing()
                        }).textFieldStyle(RoundedBorderTextFieldStyle())
                    }.padding()
                    Spacer()
                }.toolbar(content: {
                    ToolbarItemGroup(placement: .bottomBar) {
                        Button(action: {
                            messageToNextPage = "Message from \(currentPage.rawValue) Page\n\(message)"
                            currentPage = .Blue
                        }) {
                           Text("To Blue")
                        }
                        Button(action: {
                            messageToNextPage = "Message from \(currentPage.rawValue) Page\n\(message)"
                            currentPage = .Yellow
                            
                        }) {
                           Text("To Yellow")
                        }
                    }
                })
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
