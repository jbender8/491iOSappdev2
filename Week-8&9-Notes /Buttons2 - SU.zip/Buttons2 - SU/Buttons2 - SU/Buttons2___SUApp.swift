//___FILEHEADER___

import SwiftUI

@main
struct Buttons2___SUApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
