//
//  ContentView.swift
//  Buttons2 - SU
//
//  Created by Xiaoping Jia on 3/1/21.
//

import SwiftUI

struct ContentView: View {
    let labels = [ "Button 1", "Button 2" ]
    
    @State private var buttonIndex = -1
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20.0) {
            Text((buttonIndex < 0) ? "Hello State!" : "\(labels[buttonIndex]) pressed")
                .frame(maxWidth: .infinity, alignment: .leading)
            ForEach (0..<2) { i in
                Button(action: {
                    buttonIndex = i
                }) {
                    Text(labels[i])
                }
            }
            Spacer()
        }
        .padding([.top, .leading, .trailing])
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
