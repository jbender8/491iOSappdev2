//
//  ContentView.swift
//  Order My Sub - SU
//
//  Created by Xiaoping Jia on 3/6/21.
//

import SwiftUI

let subs = [
    "Blockbuster",
    "Roast Beef",
    "Italian Special",
    "Corned Beef",
    "Big \"Al\" Italian",
    "Tuna",
    "Wise Guy",
    "Chicken Salad ",
    "Caputo",
    "Veggie",
    "Prosciutto",
    "Turkey Breast",
    "American"
]

let sizes = [
    "6 inch",
    "8 inch",
    "10 inch",
    "12 inch",
    "16 inch",
    "3 foot"
]

struct ContentView: View {
    
    @State private var selectedTypeIndex = 0
    @State private var selectedSizeIndex = 0
    
    @State private var showTypeAlert = false
    @State private var showSizeAlert = false
    
    var body: some View {
        TabView {
            VStack {
                Text("Select Type").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).padding()
                Picker("", selection: $selectedTypeIndex) {
                    ForEach(0 ..< subs.count) {
                       Text(subs[$0])
                    }
                }.padding()
                Button(action: { showTypeAlert = true }) {
                    Text("Select")
                }
            }.tabItem {
                Label("Select Type", systemImage: "list.dash")
            }.alert(isPresented: $showTypeAlert) {
                Alert(
                    title: Text("Order My Sub"),
                    message: Text("You have selected \(subs[selectedTypeIndex])"),
                    primaryButton:
                        .default(Text("Confirm"),
                                 action: {}),
                    secondaryButton:
                        .destructive(Text("Cancel"),
                                     action: {})
                )
            }
            VStack {
                Text("Select Type & Size").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).padding()
                HStack {
                    Picker("", selection: $selectedTypeIndex) {
                        ForEach(0 ..< subs.count) {
                           Text(subs[$0])
                        }
                    } .frame(width: 200).clipped()
                    Picker("", selection: $selectedSizeIndex) {
                        ForEach(0 ..< sizes.count) {
                           Text(sizes[$0])
                        }
                    } .frame(width: 150).clipped()
                }.padding()
                Button(action: { showSizeAlert = true }) {
                    Text("Select")
                }
            }.tabItem {
                Label("Select Type & Size", systemImage: "square.and.pencil")
            }.alert(isPresented: $showSizeAlert) {
                Alert(
                    title: Text("Order My Sub"),
                    message: Text("You have selected \(sizes[selectedSizeIndex]) \(subs[selectedTypeIndex])"),
                    primaryButton:
                        .default(Text("Confirm"),
                                 action: {}),
                    secondaryButton:
                        .destructive(Text("Cancel"),
                                     action: {})
                )
            }
        }
    }
    

}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
