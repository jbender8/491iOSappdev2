//___FILEHEADER___

import SwiftUI

@main
struct Order_My_Sub___SUApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
