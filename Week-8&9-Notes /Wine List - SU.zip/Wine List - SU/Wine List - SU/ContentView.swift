//
//  ContentView.swift
//  Wine List - SU
//
//  Created by Xiaoping Jia on 3/1/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            List(wines) { wine in
                NavigationLink(destination: WineDetail(wine: wine)) {
                    WineRow(wine: wine)
                }
            }.navigationTitle("Wines")
        }
    }
}

struct WineRow: View {
    var wine: Wine
    
    var body: some View {
        HStack {
            Image(wine.type.rawValue)
            VStack(alignment: .leading) {
                Text(wine.name).font(.title2)
                Text(wine.shortDescription).font(.subheadline).foregroundColor(.secondary)
            }
            //.padding()
            Spacer()
        }
    }
}

struct WineDetail: View {
    var wine: Wine
    
    var body: some View {
        
        VStack(alignment: .center) {
            Text(wine.name).font(.title).fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
            Spacer().frame(height: 30)
            Text(wine.longDescription)
            
            Spacer()
        }.padding()
        .navigationBarTitle("Wine Details")
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
        WineRow(wine: wines[0])
        WineDetail(wine: wines[0])
    }
}
