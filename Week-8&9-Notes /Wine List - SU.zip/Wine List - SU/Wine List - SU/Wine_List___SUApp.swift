//___FILEHEADER___

import SwiftUI

@main
struct Wine_List___SUApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
