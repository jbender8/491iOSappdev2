//
//  ContentView.swift
//  My Home - ObservedObject - SU
//
//  Created by Xiaoping Jia on 3/7/21.
//

import SwiftUI

class Room : Identifiable, ObservableObject {
    init(_ name: String) {
        self.name = name
    }
    let id: UUID = .init()
    var name : String
    @Published var lightsOn = false
}

var rooms = [
    Room("Living Room"),
    Room("Study Room"),
    Room("Dining Room")
]

struct ContentView: View {
    
    var body: some View {
        VStack {
            Text("My Home").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .padding()
            Group {
                Text("Room Controls").font(.title2).padding()
                List(rooms) { room in
                    RoomControlView(room: room)
                }
            }
            Divider()
            Group {
                Text("Rooms").font(.title2).padding()
                List(rooms) { room in
                    RoomView(room: room)
                }
            }
            Spacer()
        }
    }
}

struct RoomControlView: View {
    
    @ObservedObject var room : Room
    
    var body: some View {
        HStack {
            Text(room.name)
            Spacer()
            Toggle("Lights", isOn: $room.lightsOn)
        }.padding()
    }
    
}

struct RoomView: View {
    
    @ObservedObject var room : Room
    
    var body: some View {
        HStack {
            Text(room.name)
            Spacer()
            Text(room.lightsOn ? "Lights On" : "Lights Off")
        }.padding().background(room.lightsOn ? Color.yellow : Color.gray)
    }
    
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
