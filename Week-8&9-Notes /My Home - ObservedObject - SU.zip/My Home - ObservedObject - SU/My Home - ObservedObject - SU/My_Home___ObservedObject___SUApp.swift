//
//  My_Home___ObservedObject___SUApp.swift
//  My Home - ObservedObject - SU
//
//  Created by Xiaoping Jia on 3/7/21.
//

import SwiftUI

@main
struct My_Home___ObservedObject___SUApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
