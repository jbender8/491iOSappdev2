//
//  ContentView.swift
//  Text Input - SU
//
//  Created by Xiaoping Jia on 3/6/21.
//

import SwiftUI

struct ContentView: View {
    @State private var text = ""
    @State private var url = ""
    @State private var email = ""
    @State private var phone = ""
    @State private var number : Int = 0
    @State private var decimal : Double = 0
    @State private var password = ""
    @State private var message = ""
    
    @State private var isAlertPresent = false
    
    var body: some View {
        VStack {
            Text("Text Input").font(.title)
                .padding()
            HStack {
                Text("Default").frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: .leading)
                TextField("Type text here", text: $text, onCommit:  {
                    UIApplication.shared.endEditing()
                })//.border(Color(UIColor.separator))
                .textFieldStyle(RoundedBorderTextFieldStyle())
            }.padding([.top, .leading, .trailing])
            HStack {
                Text("URL").frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: .leading)
                TextField("Enter a URL", text: $url, onCommit:  {
                    UIApplication.shared.endEditing()
                }).keyboardType(.URL).textFieldStyle(RoundedBorderTextFieldStyle())
            }.padding([.top, .leading, .trailing])
            HStack {
                Text("Email").frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: .leading)
                TextField("Enter an email address", text: $email, onCommit:  {
                    UIApplication.shared.endEditing()
                }).keyboardType(.emailAddress).textFieldStyle(RoundedBorderTextFieldStyle())
            }.padding([.top, .leading, .trailing])
            HStack {
                Text("Phone").frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: .leading)
                TextField("Enter a phone number", text: $phone).keyboardType(.phonePad).textFieldStyle(RoundedBorderTextFieldStyle())
            }.padding([.top, .leading, .trailing])
            HStack {
                Text("Number").frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: .leading)
                TextField("Enter a number", value: $number, formatter: NumberFormatter()).keyboardType(.numberPad).textFieldStyle(RoundedBorderTextFieldStyle())
            }.padding([.top, .leading, .trailing])
            HStack {
                Text("Decimal").frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: .leading)
                TextField("Enter a decimal", value: $decimal, formatter: NumberFormatter()).keyboardType(.decimalPad).textFieldStyle(RoundedBorderTextFieldStyle())
            }.padding([.top, .leading, .trailing])
            HStack {
                Text("Password").frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: .leading)
                SecureField("Enter a pssword", text: $password).textFieldStyle(RoundedBorderTextFieldStyle())
            }.padding([.top, .leading, .trailing])
            HStack(alignment: .top) {
                Text("Message").frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: .leading)
                TextEditor(text: $message).border(Color(UIColor.separator))
            }.frame(alignment: .top).padding([.top, .leading, .trailing])
            Spacer()
        }.onTapGesture {
            UIApplication.shared.endEditing()
        }.toolbar(content: {
            ToolbarItemGroup(placement: .bottomBar) {
                Button(action: {
                    isAlertPresent = true
                }) {
                   Text("Done")
                }
                Button(action: {
                    text = ""
                    url = ""
                    email = ""
                    phone = ""
                    number = 0
                    decimal = 0
                    password = ""
                    message = ""
                }) {
                   Text("Clear")
                }
            }
        }).alert(isPresented: $isAlertPresent) {
            Alert(title: Text("Text Input"),
                  message: Text("""
                    Default:  \(text)
                    URL:      \(url)
                    Email:    \(email)
                    Phone:    \(phone)
                    Number:   \(number)
                    Decimal:  \(decimal)
                    Password: \(password)
                    Message:  \(message)
                    """),
                  //.multilineTextAlignment(.leading),
                  dismissButton: nil)
        }
    }
}

struct Background<Content: View>: View {
    private var content: Content

    init(@ViewBuilder content: @escaping () -> Content) {
        self.content = content()
    }

    var body: some View {
        Color.white
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .overlay(content)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
