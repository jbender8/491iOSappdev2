//
//  ContentView.swift
//  Image - SU
//
//  Created by Xiaoping Jia on 1/4/20.
//  Copyright © 2020 DePaul University. All rights reserved.
//

import SwiftUI

let names = [ "Lake Front", "Cloud Gate", "Picasso"]

struct ContentView: View {
    
    @State var imageName = names[0] 
    
    var body: some View {
        VStack {
            HStack {
                /*
                Button(action: {
                    self.imageName = names[0]
                }) {
                    Text(names[0])
                }
                Spacer()
                Button(action: {
                    self.imageName = names[1]
                }) {
                    Text(names[1])
                }
                Spacer()
                Button(action: {
                    self.imageName = names[2]
                }) {
                    Text(names[2])
                }
                 */
                ForEach (0 ..< names.count) { i in
                    if (i > 0) {
                        Spacer()
                    }
                    Button(action: {
                        self.imageName = names[i]
                    }) {
                        Text(names[i])
                    }
                }
            }
            .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
            Spacer()
            
            Image(imageName)
            
            Spacer()
            
        }
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
