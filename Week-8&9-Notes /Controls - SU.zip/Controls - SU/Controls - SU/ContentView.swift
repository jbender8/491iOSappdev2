//
//  ContentView.swift
//  Controls - SU
//
//  Created by Xiaoping Jia on 1/4/20.
//  Copyright © 2020 DePaul University. All rights reserved.
//

import SwiftUI

let names = [ "Botticelli", "Raffaello", "Uccello" ]

struct ContentView: View {
    
    @State private var selectedNameIndex = 0
    @State private var switchOn = false
    @State private var sliderValue = 0.0
    @State private var stepperValue = 0
    @State private var hiddenIndex = 1
    var hidden : Bool {
        hiddenIndex == 0
    }
    @State var disableIndex = 1
    
    var body: some View {
        let switch1 =  Toggle("Switch", isOn: $switchOn).labelsHidden().disabled(disableIndex == 0)
        let switch2 =  Toggle("Switch", isOn: $switchOn).labelsHidden().disabled(disableIndex == 0)
        let slider = Slider(value: $sliderValue, in: 0...100).disabled(disableIndex == 0)
            
        VStack {
            Picker("Names", selection: $selectedNameIndex) {
                ForEach(0 ..< names.count) { i in
                    Text(names[i]).tag(i)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            Text(names[selectedNameIndex]).frame(maxWidth: .infinity)
            HStack {
                Text("Switch \(switchOn ? "on" : "off")").frame(width: 100, height: 40, alignment: .leading)
                if (!hidden) {
                    switch1
                }
                Spacer()
                if (!hidden) {
                    switch2
                }
            }
            HStack {
                Text("Value \(Int(sliderValue))")
                    .frame(width: 100, height: 40, alignment: .leading)
                if (!hidden) {
                    slider
                } else {
                    Spacer()
                }
            }
            HStack {
                Stepper(value: $stepperValue, in: 0...100, label: {
                        Text("Value \(stepperValue)")
                })
                //Spacer()
            }//.frame(spacing: 0)
            
            Picker("hidden", selection: $hiddenIndex) {
                Text("Hide controls").tag(0)
                Text("Show controls").tag(1)
            }.pickerStyle(SegmentedPickerStyle())
            .onChange(of: hiddenIndex) { _ in
                print("Hidden \(hiddenIndex)")
            }
            Picker("disable", selection: $disableIndex) {
                Text("Disbale controls").tag(0)
                Text("Enable controls").tag(1)
            }.pickerStyle(SegmentedPickerStyle())
            .onChange(of: hiddenIndex) { _ in
                print("Dsiable \(disableIndex)")
            }
            
            Spacer()
            
            Image(names[selectedNameIndex])
                .resizable()
                .aspectRatio(contentMode: .fit)
            
            Spacer()
        }.padding(.all).frame(alignment: .leading)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
